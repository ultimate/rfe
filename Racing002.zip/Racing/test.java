import java.awt.image.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.Cursor;





public class test
{
  public static void main(String args[])
  {
    switch(args[0].charAt(0))
    {
      case('p'):  ImageIcon ii = new ImageIcon(args[0]);
	                Image i = ii.getImage();
	                PixelGrabber pg = new PixelGrabber(i,0,0,i.getWidth(null),i.getHeight(null),true);

	                try
	                {
	                  //pg.startGrabbing();
	                  pg.grabPixels();
	                }
	                catch(Exception e)
	                {}

	                int[] pixel = (int[])pg.getPixels();

	                System.out.println(ii + " " + i + " " + pg + " "); //+ pixel.length);

	                for(int h = 0; h < pixel.length; h++)
	                {
	                  System.out.print("" + pixel[h] + "      \t");
	                  String s = Integer.toBinaryString(pixel[h]);
	                  System.out.println( Integer.parseInt(s.substring(0,8),2) + ","
	                                    + Integer.parseInt(s.substring(8,16),2) + ","
	                                    + Integer.parseInt(s.substring(16,24),2) + ","
	                                    + Integer.parseInt(s.substring(24,32),2) );
	                  System.out.println(s);
	                  System.out.println(Integer.toHexString(pixel[h]).toUpperCase());
	                }
	                break;
      case('w'):  final JTextField textField;
	                JFrame frame = new JFrame();
	                frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
	                //frame.setLocation(-200, 0); // uncomment this line to hide the dummy frame
	                //frame.setVisible( true );
	                JWindow window = new JWindow(frame); // this works
	                //JWindow window = new JWindow(); // this doesn't work

	                window.getContentPane().add( textField = new JTextField(10), BorderLayout.NORTH );
                  JButton jb = new JButton("Button");
                  myAL a = new myAL(frame);
                  jb.addActionListener(a);
 	                window.getContentPane().add( jb );
	                window.getContentPane().add( new JCheckBox("CheckBox"), BorderLayout.SOUTH );

	                window.setBounds(50, 50, 200, 200);
	                window.setVisible(true);
                  break;
    }
  }

  private static class myAL implements ActionListener
  {
    private JFrame f;
    public myAL(JFrame frame)
    {
    	f = frame;
    }
    public void actionPerformed(ActionEvent e)
    {
    	f.setVisible(!f.isVisible());
    }
  }
}