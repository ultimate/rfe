package RacingForEngineers.ActionListeners;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.Cursor;
import javax.swing.event.*;

import RacingForEngineers.*;
import RacingForEngineers.Panels.*;
import RacingForEngineers.ActionListeners.*;

public class MousePositionListener implements MouseInputListener, RFEConstants
{
  public void mouseClicked(MouseEvent e)
  {
    try
    {
    	c[p.getActualPlayer()].addPoint(c[p.getActualPlayer()].getFocusedPoint());
      c[p.getActualPlayer()].setFocusedPoint(null);
      p.nextPlayer();
      rfegui.getGameFieldPanel().repaint();
    }
    catch(Exception ex)
    {
    }
  }

  public void mouseMoved(MouseEvent e)
  {
  	//double x = calcPointToCoordinate(e.getX());
    //double y = calcPointToCoordinate(e.getY());
    //rfegui.getStatusPanel().setMousePosition(x,y);
    rfegui.getStatusPanel().setMousePosition(calcPointToCoordinate(e.getX()),calcPointToCoordinate(e.getY()));

    /* �nderung, damit korrektes Entzeichnen
    try
    {
    	if(c[p.getActualPlayer()].getFocusedPoint() != null)
				c[p.getActualPlayer()].unmarkPoint(rfegui.getGameFieldPanel().getGraphics(),c[p.getActualPlayer()].getFocusedPoint(),c[p.getActualPlayer()].getPossibilityColor());
    }
    catch(Exception ex)
    {
    }
    */
    try
    {
      //Point possibleP = c[p.getActualPlayer()].getPossiblePoint(x,y);
      Point possibleP = c[p.getActualPlayer()].getPossiblePoint((int)e.getX(),(int)e.getY());
      if(possibleP != c[p.getActualPlayer()].getFocusedPoint())
      {
      	c[p.getActualPlayer()].setFocusedPoint(possibleP);
      	// weg, damit korrektes Zeichnen: c[p.getActualPlayer()].markPoint(rfegui.getGameFieldPanel().getGraphics(),possibleP,c[p.getActualPlayer()].getPossibilityColor());
      }
    }
    catch(Exception ex)
    {
      c[p.getActualPlayer()].setFocusedPoint(null);
    }
    rfegui.getGameFieldPanel().repaint();    // f�r korrektes Zeichnen
  }

  public void mouseDragged(MouseEvent e)  {    mouseMoved(e);  }
	public void mousePressed(MouseEvent e)  {  }
  public void mouseExited(MouseEvent e)  {  }
  public void mouseEntered(MouseEvent e)  {  }
  public void mouseReleased(MouseEvent e)  {  }

  public double calcPointToCoordinate(int XOrY)
  {
  	double dXOrY = Math.round(XOrY * 100.0 / track.getGridSize())/100.0;
    return dXOrY;
  }
}