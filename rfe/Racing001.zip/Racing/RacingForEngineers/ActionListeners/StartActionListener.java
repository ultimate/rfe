package RacingForEngineers.ActionListeners;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.Cursor;

import RacingForEngineers.*;
import RacingForEngineers.Panels.*;
import RacingForEngineers.ActionListeners.*;

public class StartActionListener implements ActionListener, RFEConstants
{
  private NewGameGUI nggui = new NewGameGUI();

  public StartActionListener()
  {
    nggui.setSize(NewGameGUISize);
    nggui.setLocation(200,200);
    nggui.addWindowListener(new NewGameGUIListener());
  }

  public void actionPerformed(ActionEvent e)
  {
    nggui.setVisible(true);
  }
}