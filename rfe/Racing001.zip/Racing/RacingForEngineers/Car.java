package RacingForEngineers;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.Cursor;

import RacingForEngineers.*;
import RacingForEngineers.Panels.*;
import RacingForEngineers.ActionListeners.*;

public class Car implements RFEConstants
{
  public static final Color[] playerColors = { new Color(255,  0,  0),
  										                         new Color(128,  0,  0),
	                                             new Color(  0,255,  0),
	                                             new Color(  0,128,  0),
	                                             new Color(  0,  0,255),
	                                             new Color(  0,  0,128),
	                                             new Color(  0,255,255),
	                                             new Color(  0,128,128),
	                                             new Color(255,  0,255),
	                                             new Color(128,  0,128),
	                                             new Color(255,255,  0),
	                                             new Color(128,128,  0),
	                                             new Color(128,128,128),
	                                             new Color(  0,  0,  0) };
	public static final int FILLED_SMALL = 1;
  public static final int FILLED_LARGE = 2;
  public static final int EMPTY_SMALL = -1;
  public static final int EMPTY_LARGE = -2;

  private Color carColor;
  private Color possColor;
  private Route r;
  private Point[][] possibleMoves = new Point[3][3];
  private boolean[][] possibleValidMoves = new boolean[3][3];
	private Point focusedPoint = null;

  private int carSize = (int)track.getGridSize()/2 + ((track.getGridSize()/2)-1)%2;

  public Car(Color c, Point p)
  {
    carColor = c;
    possColor = new Color( (carColor.getRed()+255)/2,
                           (carColor.getGreen()+255)/2,
                           (carColor.getBlue()+255)/2);
    r = new Route(p);
  }

  public Car(int colorIndex, Point p)
  {
    carColor = playerColors[colorIndex];
    possColor = new Color( (carColor.getRed()+255)/2,
                           (carColor.getGreen()+255)/2,
                           (carColor.getBlue()+255)/2);
    r = new Route(p);
  }

  public void addPoint(Point p)
  {
    r.addPoint(p);
  }

  public int getRouteLength()
  {
    return r.getLength();
  }

  public Color getCarColor()
  {
  	return carColor;
  }

  public Color getPossibilityColor()
  {
    return possColor;
  }

  public void setFocusedPoint(Point p)
  {
    if(p!=null)
    	focusedPoint = new Point(p);
    else
    	focusedPoint = null;
  }

  public Point getFocusedPoint()
  {
    return focusedPoint;
  }

  public void drawCar(Graphics g, boolean drawRoute, int index)
  {
    Color oldColor = g.getColor();
    g.setColor(carColor);
    if(drawRoute)
    	r.drawRoute(g, this);
    Point position = r.getPoint(index);
    g.fillOval( (int) ( position.getX() - (carSize/2) ), (int) ( position.getY() - (carSize/2) ), carSize, carSize);
    g.setColor(oldColor);
  }

  public void drawPoint(Graphics g, Point p, Color c, int type)
  {
    Color oldColor = g.getColor();
    g.setColor(c);
    switch (type)
    {
    	case FILLED_SMALL:
				g.fillOval( (int) ( p.getX() - (carSize/2)     ), (int) ( p.getY() - (carSize/2)     ), carSize, carSize);
        break;
      case EMPTY_SMALL:
				g.drawOval( (int) ( p.getX() - (carSize/2)     ), (int) ( p.getY() - (carSize/2)     ), carSize-1, carSize-1);
        break;
    	case FILLED_LARGE:
				g.fillOval( (int) ( p.getX() - (carSize/2) - 2 ), (int) ( p.getY() - (carSize/2) - 2 ), carSize+3, carSize+3);
        break;
      case EMPTY_LARGE:
				g.drawOval( (int) ( p.getX() - (carSize/2) - 2 ), (int) ( p.getY() - (carSize/2) - 2 ), carSize+3, carSize+3);
        break;
    }
    g.setColor(oldColor);
	}

  public void markPoint(Graphics g, Point p, Color c)
  {
  	drawPoint(g,p,c,EMPTY_LARGE);
  }

  public void unmarkPoint(Graphics g, Point p, Color c)
  {
		markPoint(g,p,bgColor); // hier haben wir ein problem! malt mit hintergrundfarbe, statt dem was tats�chlich im hintergrund ist!
    Color oldColor = g.getColor();
    g.setColor(gridColor);
    g.drawLine( (int) ( p.getX() - carSize ), (int) ( p.getY() 					 ),
								(int) ( p.getX() + carSize ), (int) ( p.getY() 					 ) );
    g.drawLine( (int) ( p.getX()  				 ), (int) ( p.getY() - carSize ),
								(int) ( p.getX()  				 ), (int) ( p.getY() + carSize ) );
    g.setColor(oldColor);
    drawPoint(g,p,c,FILLED_SMALL);
  }

  public void calcPossibleMoves(Graphics g)
  {
  	Point center;
    Point last;
  	if (r.getLength() == 0)
    {
    	center = r.getPoint(0);
      last = center;
    }
    else
    {
    	//abfrage der einflussgr��en oil, sand, etc.
     	last = r.getPoint( r.getLength() );
    	Point prelast = r.getPoint( r.getLength()-1);
  		center = 	new Point( (int)(2*last.getX() - prelast.getX()) ,
    											 (int)(2*last.getY() - prelast.getY())	);
    }
    for(int x = 0; x < 3; x++)
    {
    	for(int y = 0; y < 3; y++)
      {
      	possibleMoves[x][y] = new Point ( (int)( center.getX() + (x - 1)*track.getGridSize() ) ,
        																	(int)( center.getY() + (y - 1)*track.getGridSize() ) );

				if( ( ( x==1 ) && ( y==1 ) ) || ( possibleMoves[x][y].getX() < 0 ) || ( possibleMoves[x][y].getY() < 0 ) || ( possibleMoves[x][y].getX() >= track.getTrackSize().getWidth() ) || ( possibleMoves[x][y].getY() >= track.getTrackSize().getHeight() ) )
        	possibleValidMoves[x][y] = false;
        else
          possibleValidMoves[x][y] = track.isValidMove(last,possibleMoves[x][y]);

				if( !possibleValidMoves[x][y] )
        	drawPoint(g,possibleMoves[x][y],possColor,EMPTY_SMALL);
        else
        	drawPoint(g,possibleMoves[x][y],possColor,FILLED_SMALL);
    	}
    }
  }

  public Point getPossiblePoint(double px, double py) throws Exception
  {
  	for(int x = 0; x < 3; x++)
    {
    	for(int y = 0; y < 3; y++)
      {
      	if( ( possibleValidMoves[x][y] ) && (possibleMoves[x][y].distance(px,py) < (double)track.getGridSize()/3.0/*1.0/3.0*/) )
        {
          return possibleMoves[x][y];
        }
      }
    }
  	throw new Exception();
  }

  public void setCarSize(int carSize)
  {
    this.carSize = carSize;
  }

  public int getCarSize()
  {
    return carSize;
  }
}