package RacingForEngineers;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.Cursor;

import RacingForEngineers.*;
import RacingForEngineers.Panels.*;
import RacingForEngineers.ActionListeners.*;
import RacingForEngineers.Parts.*;

public class NewGameGUI extends JWindow implements RFEConstants
{
  private JLabel 			trackL, roundsL, roundsL2, nopL, nopL2, playerL, titleL, descL;
  private JButton 		trackB, playerDefB, playerCustB, applyB, closeB;
  private JTextField 	trackTF;
  private IncDecButton roundsIncB, roundsDecB, nopIncB, nopDecB;
  private JRadioButton trackCusRB, trackDefRB;
  private JComboBox   trackDefCB;
  private TrackPreviewPanel tpP;

	public NewGameGUI()
  {
    this.setSize(NewGameGUISize);

    JPanel myContentPane = new JPanel();
  	myContentPane.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED),BorderFactory.createEtchedBorder()));
    this.setContentPane(myContentPane);
    this.getContentPane().setLayout(null);

    titleL = new JLabel("--- Game Setup ---");
    titleL.setBounds(5+border, 5+border, (int)NewGameGUISize.getWidth()-10-2*border, 25);
    titleL.setHorizontalAlignment(SwingConstants.CENTER);
    titleL.setFont(new Font(titleL.getFont().getName(), Font.PLAIN, 18));

    trackL = new JLabel("Track:");
    trackL.setBounds(10+border, 40+border, 80, 25);

    trackCusRB = new JRadioButton("Custom:");
    trackCusRB.setBounds(95+border, 40+border, 80, 25);

    trackTF = new JTextField("track");
    trackTF.setBounds(180+border, 40+border, 208, 25);

    trackDefRB = new JRadioButton("Default:");
    trackDefRB.setBounds(95+border, 70+border, 80, 25);

    trackDefCB = new JComboBox();
    trackDefCB.setBounds(180+border, 70+border, 207, 25);

    trackB = new JButton("Preview");
    trackB.setBounds(95+border, 100+border, 80, 25);

    roundsL = new JLabel("Rounds:");
    roundsL.setBounds(10+border, 137+border, 110, 25);

    roundsL2 = new JLabel("1");
    roundsL2.setBounds(125+border, 137+border, 25, 25);
    roundsL2.setHorizontalAlignment(SwingConstants.RIGHT);

    roundsIncB = new IncDecButton('+');
    roundsIncB.setBounds(155+border, 137+border, 20, 12);

    roundsDecB = new IncDecButton('-');
    roundsDecB.setBounds(155+border, 149+border, 20, 12);

    nopL = new JLabel("Number of players:");
    nopL.setBounds(10+border, 174+border, 110, 25);

    nopL2 = new JLabel("2");
    nopL2.setBounds(125+border, 174+border, 25, 25);
    nopL2.setHorizontalAlignment(SwingConstants.RIGHT);

    nopIncB = new IncDecButton('+');
    nopIncB.setBounds(155+border, 174+border, 20, 12);

    nopDecB = new IncDecButton('-');
    nopDecB.setBounds(155+border, 186+border, 20, 12);

    playerL = new JLabel("Player-Config:");
    playerL.setBounds(10+border, 211+border, 100, 25);

    playerCustB = new JButton("Custom");
    playerCustB.setBounds(95+border, 211+border, 80, 25);

    playerDefB = new JButton("Default");
    playerDefB.setBounds(95+border, 241+border, 80, 25);

    tpP = new TrackPreviewPanel();
    tpP.setBounds(180+border, 100+border, 208, 167);
    tpP.setBorder(BorderFactory.createEtchedBorder());

    tpP.setTrack("Data/Tracks/default0.PNG");
    tpP.repaint();

    applyB = new JButton("Apply and Start New Game");
    applyB.setBounds(5+border, 278+border, (int)NewGameGUISize.getWidth()-10-2*border, 25);
    applyB.addActionListener(new ApplyStartActionListener(this));

    closeB = new JButton();
    closeB.setIcon(new ImageIcon("Data/Images/closeIcon.jpg"));
    closeB.setBounds((int)NewGameGUISize.getWidth()-2*border-27,border+4,26,25);
    closeB.addActionListener(new ApplyStartActionListener(this));
    closeB.setMargin(new Insets(-5,-5,-5,-5));

    this.getContentPane().add(titleL, null);
    this.getContentPane().add(trackL, null);
    this.getContentPane().add(trackB, null);
    this.getContentPane().add(trackCusRB, null);
    this.getContentPane().add(trackTF, null);
    this.getContentPane().add(trackDefRB, null);
    this.getContentPane().add(trackDefCB, null);
    this.getContentPane().add(roundsL, null);
    this.getContentPane().add(roundsL2, null);
    this.getContentPane().add(roundsIncB, null);
    this.getContentPane().add(roundsDecB, null);
    this.getContentPane().add(nopL, null);
    this.getContentPane().add(nopL2, null);
    this.getContentPane().add(nopIncB, null);
    this.getContentPane().add(nopDecB, null);
    this.getContentPane().add(playerL, null);
    this.getContentPane().add(playerDefB, null);
    this.getContentPane().add(playerCustB, null);
    this.getContentPane().add(applyB, null);
    this.getContentPane().add(closeB, null);
    this.getContentPane().add(tpP, null);
  }
}