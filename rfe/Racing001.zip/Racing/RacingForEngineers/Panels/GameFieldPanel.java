package RacingForEngineers.Panels;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.Cursor;
import java.awt.image.*;

import RacingForEngineers.*;
import RacingForEngineers.Panels.*;
import RacingForEngineers.ActionListeners.*;

public class GameFieldPanel extends JPanel implements RFEConstants//, ImageObserver
{
	public GameFieldPanel()
  {
  	this.addMouseListener(new MousePositionListener());
  	this.addMouseMotionListener(new MousePositionListener());
  }

  public void paint(Graphics g)
  {
    g.setColor(bgColor);
    g.fillRect(0,0,10000,10000);

    g.drawImage( track.getTrackIcon().getImage(), 0, 0, null);
    drawGrid(g);
    /* draw Colors
    for(int i = 0; i < playerColors.length; i=i+2)
    {
      c[0].drawPoint(g,new Point(i+5, 20),playerColors[i],Car.FILLED_LARGE);
      c[0].drawPoint(g,new Point(i+5, 21),playerColors[i+1],Car.FILLED_LARGE);
    }
    */
    for(int i = 0; i < p.getNumberOfPlayers(); i++)
    {
    	c[i].drawCar(g, true, c[i].getRouteLength());
    }
    c[p.getActualPlayer()].calcPossibleMoves(g);
    if( c[p.getActualPlayer()].getFocusedPoint() != null)
    	c[p.getActualPlayer()].markPoint(g,c[p.getActualPlayer()].getFocusedPoint(),c[p.getActualPlayer()].getPossibilityColor());
  }

  public void drawGrid(Graphics g)
  {
  	Color oldColor = g.getColor();
    g.setColor(gridColor);
    for( int h = 0; h <= this.getSize().getWidth(); h += track.getGridSize())
    {
      g.drawLine(h,0,h,(int)this.getSize().getHeight()-2);
    }
    for( int v = 0; v <= this.getSize().getHeight(); v += track.getGridSize())
    {
      g.drawLine(0,v,(int)this.getSize().getWidth()-2,v);
    }
    g.setColor(oldColor);
  }
}