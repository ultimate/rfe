package RacingForEngineers.Parts;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.Cursor;

import RacingForEngineers.*;
import RacingForEngineers.Panels.*;
import RacingForEngineers.ActionListeners.*;

public class IncDecButton extends JButton implements RFEConstants
{
	private char incOrDec;

  public IncDecButton(char incOrDec)
  {
  	this.incOrDec = incOrDec;
    if(incOrDec == '+')
    	this.setIcon(new ImageIcon("Data/Images/plus.jpg"));
    else if(incOrDec == '-')
    	this.setIcon(new ImageIcon("Data/Images/minus.jpg"));

    this.setMargin(new Insets(-5,-5,-5,-5));
  }
}