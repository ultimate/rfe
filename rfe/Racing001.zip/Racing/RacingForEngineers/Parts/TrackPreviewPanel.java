package RacingForEngineers.Parts;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.Cursor;

import RacingForEngineers.*;
import RacingForEngineers.Panels.*;
import RacingForEngineers.ActionListeners.*;

public class TrackPreviewPanel extends JPanel implements RFEConstants
{
  private ImageIcon trackIcon = null;

  public TrackPreviewPanel()
  {
  }

	public TrackPreviewPanel(String trackName)
  {
    setTrack(trackName);
  }

  public void setTrack(String trackName)
  {
  	trackIcon = new ImageIcon(trackName);
  }

  public void paint(Graphics g)
  {
  	g.drawImage( trackIcon.getImage(), border, border, (int)this.getSize().getWidth()-2*border, (int)this.getSize().getHeight()-2*border, null);
	}
}