package RacingForEngineers;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.Cursor;

import RacingForEngineers.*;
import RacingForEngineers.Panels.*;
import RacingForEngineers.ActionListeners.*;

public interface RFEConstants
{
  Object syncobject = new Object();
  Dimension GUISize = new Dimension(1200,900);
  Dimension NewGameGUISize = new Dimension(400,316);
  Color gridColor = new Color(150,150,150);
  Color bgColor = new Color(238,238,238);
  PlayerCounter p = new PlayerCounter();
  Car[] c = new Car[p.getMaxNumberOfPlayers()];
  int barHeight = 30;
  int border = 4;
  RFETrack track = new RFETrack();
  RFEGUI rfegui = new RFEGUI();
}