package RacingForEngineers;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.Cursor;

import RacingForEngineers.*;
import RacingForEngineers.Panels.*;
import RacingForEngineers.ActionListeners.*;

public class RFEGUI extends JWindow implements RFEConstants
{
  private GameFieldPanel gameP = new GameFieldPanel();
  private MenuPanel menuP = new MenuPanel();
  private StatusPanel statusP = new StatusPanel();
  private OptionPanel optionP = new OptionPanel();

	public RFEGUI()
  {
  	init();
  }

  public void init()
  {
    this.setSize(GUISize);
    this.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
    //Toolkit.createCustomCursor(java.awt.Image, java.awt.Point, java.lang.String),

    JPanel myContentPane = new JPanel();
  	myContentPane.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED),BorderFactory.createEtchedBorder()));
    this.setContentPane(myContentPane);
    this.getContentPane().setLayout(null);

    try
    {
      String s = "Data/Tracks/default" + (int)(Math.random()*3.0) + ".PNG";
      System.out.println(s);
      track.setTrack(s);
    }
    catch(Exception e)
    {
      System.out.println("Error in Track!");
    }

    p.setNumberOfPlayers(2);
    for(int i = 0; i < p.getNumberOfPlayers(); i++)
    {
      c[i] = new Car(i,new Point((5+2*i)*track.getGridSize(),2*track.getGridSize()));
    }


		gameP.setBounds(border,barHeight+border,(int)track.getTrackSize().getWidth(),(int)track.getTrackSize().getHeight());
    gameP.setBorder(BorderFactory.createEtchedBorder());

    menuP.setBounds(border,border,(int)GUISize.getWidth()-2*border,barHeight);
    menuP.setBorder(BorderFactory.createEtchedBorder());

    statusP.setBounds(border,(int)GUISize.getHeight()-barHeight-border,(int)GUISize.getWidth()-2*border,barHeight);
    statusP.setBorder(BorderFactory.createEtchedBorder());

    optionP.setBounds(border+1+(int)track.getTrackSize().getWidth(),barHeight+border,(int)(GUISize.getWidth()-2*border-track.getTrackSize().getWidth()-1),(int)track.getTrackSize().getHeight()+1);
    optionP.setBorder(BorderFactory.createEtchedBorder());

    this.getContentPane().add(gameP, null);
    this.getContentPane().add(menuP, null);
    this.getContentPane().add(statusP, null);
    this.getContentPane().add(optionP, null);
  }

  public GameFieldPanel getGameFieldPanel()
  {
    return gameP;
  }

  public StatusPanel getStatusPanel()
  {
    return statusP;
  }

  public MenuPanel getMenuPanel()
  {
    return menuP;
  }
}