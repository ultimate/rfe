package RacingForEngineers;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.Cursor;

import RacingForEngineers.*;
import RacingForEngineers.Panels.*;
import RacingForEngineers.ActionListeners.*;

public class RFETrack implements RFEConstants
{
  public static final int BORDER = 0;
  public static final int TERRAIN = 1;
  public static final int FINISH = 2;
  public static final int CHECK = 3;
  public static final int OIL = 4;
  public static final int SAND = 5;
  public static final int BUMP = 6;
  public static final int SPEED = 7;
  private static final Dimension trackSize = new Dimension(1001,801);

  private int gridSize = 20;

  private ImageIcon trackIcon;
	private int[][] field = new int[(int)trackSize.getWidth()][(int)trackSize.getHeight()];

  public RFETrack()
  {
  }

  public RFETrack(String imageSource) throws Exception
  {
  	setTrack(imageSource);
  }

  private int[][] getFieldArray(ImageIcon trackIcon) throws Exception
  {
    Image i = trackIcon.getImage();
    int w = i.getWidth(null);
    int h = i.getHeight(null);
    PixelGrabber pg = new PixelGrabber(i, 0, 0, w, h, true);
    pg.grabPixels();
    int[] pixels = (int[])pg.getPixels();
		// STATUSABFRAGE DES ERSTEN PIXELS
    // --> RUNDEN   (4 bit)
    // --> RICHTUNG 	(1 bit)
    // --> ANZAHL CHECKPOINTS		(3 bit)
    // --> RECOMMEND NUMBERS OF PLAYERS 	(3 bit)
    // --> RECOMMEND MAXIMUM TIME  (5 bit)
    // --> FOR FREAKS --> L�NGE n DER NACHFOLGENDEN ZEICHENKETTE IN PIXEL		(8 bit)
    // FOR FREAKS N�CHSTE n. PIXEL
    // --> n*3 ZEICHEN TEXT!
    // FOR FREAKS n+1. PIXEL
    // --> CONTAINS UNIQUE CODE AND CODE FOR DECRIPTION
    int[][] returnArray = new int[w][h];
    for(int x = 0; x < w; x++)
    {
    	for(int y = 0; y < h; y++)
      {
	      String hexColor = Integer.toHexString(pixels[x+y*w]).toUpperCase();
  	    if(hexColor.substring(2,8).equals("000000"))       //   0,  0,  0 for Border
    	    returnArray[x][y] = BORDER;
      	else if(hexColor.substring(2,8).equals("FF0000"))  //	255,  0,  0 for Finish
	      	returnArray[x][y] = FINISH;
  	    else if(hexColor.substring(2,8).equals("000080"))  //	  0,  0,128 for Check
    	  	returnArray[x][y] = CHECK;
      	else if(hexColor.substring(2,8).equals("464600"))  //  70, 70,  0 for Oil
	      	returnArray[x][y] = OIL;
  	    else if(hexColor.substring(2,8).equals("C8C864"))  // 200,200,100 for Sand
    	  	returnArray[x][y] = SAND;
      	else if(hexColor.substring(2,8).equals("FF8000"))  // 255,128,  0 for Bump
	      	returnArray[x][y] = BUMP;
  	    else if(hexColor.substring(2,8).equals("00FF00"))  //   0,255,  0 for Speed
    	  	returnArray[x][y] = SPEED;
      	else
	      	returnArray[x][y] = TERRAIN;
      }
    }
    return returnArray;
  }

  public boolean isValidMove(Point p1, Point p2)
  {
    return !moveContainsTerrain(p1,p2,BORDER);
  }

  public boolean moveContainsTerrain(Point p1, Point p2, int terrainToTest)
  {
   	if( ( field[(int)p1.getX()][(int)p1.getY()] == terrainToTest ) || ( field[(int)p2.getX()][(int)p2.getY()] == terrainToTest ) )
    	return true;
  	int dx = (int)(p2.getX() - p1.getX());
  	if( dx < 0 )
    	return moveContainsTerrain(p2,p1,terrainToTest);
    int dy = (int)(p2.getY() - p1.getY());
    if( dx == 0 )
    {
    	while( dy < 0 )
      {
        if( field[(int)p1.getX()][(int)p1.getY()+dy] == terrainToTest )
          return true;
        dy++;
      }
      while( dy > 0)
      {
        if( field[(int)p1.getX()][(int)p1.getY()+dy] == terrainToTest )
          return true;
        dy--;
      }
    }
    else if( dy == 0 )
    {
    	while( dx < 0 )
      {
        if( field[(int)p1.getX()+dx][(int)p1.getY()] == terrainToTest )
          return true;
        dx++;
      }
      while( dx > 0)
      {
        if( field[(int)p1.getX()+dx][(int)p1.getY()] == terrainToTest )
          return true;
        dx--;
      }
    }
    else if( dx == 1 && Math.abs(dy) == 1 )
    {
    	return false;
    }
    else if( (double)dy/(double)dx > 0 )
    {
    	double m 		= 	(double)	dy	/	(double)	dx;
      double my 	= 	(double)(dy-2)/	(double)	dx;
      double mx 	= 	(double)	dy	/	(double)(dx-2);
      double mxy 	= 	(double)(dy-2)/	(double)(dx-2);

      double a 		= Math.atan(m);
      double ay 	= Math.atan(my);
      double ax 	= Math.atan(mx);
      double axy 	= Math.atan(mxy);

      if(	Math.min( Math.min( Math.abs(a-ay), Math.abs(a-ax) ), Math.abs(a-axy) ) ==  Math.abs(a-ay))
      	return moveContainsTerrain( new Point((int)p1.getX()	, (int)p1.getY()+1), new Point((int)p2.getX()	 , (int)p2.getY()-1) , terrainToTest);
      else if (	Math.min( Math.min( Math.abs(a-ay), Math.abs(a-ax) ), Math.abs(a-axy) ) ==  Math.abs(a-ax) )
        return moveContainsTerrain( new Point((int)p1.getX()+1, (int)p1.getY()	), new Point((int)p2.getX()-1, (int)p2.getY()  ) , terrainToTest);
      else
      	return moveContainsTerrain( new Point((int)p1.getX()+1, (int)p1.getY()+1), new Point((int)p2.getX()-1, (int)p2.getY()-1) , terrainToTest);
    }
    else
    {
    	double m 		= 	(double)	dy	/	(double)	dx;
      double my 	= 	(double)(dy-2)/	(double)	dx;
      double mx 	= 	(double)	dy	/	(double)(dx-2);
      double mxy 	= 	(double)(dy-2)/	(double)(dx-2);

      double a 		= Math.atan(m);
      double ay 	= Math.atan(my);
      double ax 	= Math.atan(mx);
      double axy 	= Math.atan(mxy);

      if(	Math.min( Math.min( Math.abs(a-ay), Math.abs(a-ax) ), Math.abs(a-axy) ) ==  Math.abs(a-ay))
      	return moveContainsTerrain( new Point((int)p1.getX()	, (int)p1.getY()-1), new Point((int)p2.getX()	 , (int)p2.getY()+1) , terrainToTest);
      else if (	Math.min( Math.min( Math.abs(a-ay), Math.abs(a-ax) ), Math.abs(a-axy) ) ==  Math.abs(a-ax) )
        return moveContainsTerrain( new Point((int)p1.getX()+1, (int)p1.getY()	), new Point((int)p2.getX()-1, (int)p2.getY()  ) , terrainToTest);
      else
      	return moveContainsTerrain( new Point((int)p1.getX()+1, (int)p1.getY()-1), new Point((int)p2.getX()-1, (int)p2.getY()+1) , terrainToTest);
    }
    return false;
  }


  public ImageIcon getTrackIcon()
  {
    return trackIcon;
  }

  public void setTrack(String imageSource) throws Exception
  {
  	trackIcon = new ImageIcon(imageSource);
    int[][] tempArray = getFieldArray(trackIcon);
    if( ( tempArray.length != trackSize.getWidth() ) || ( tempArray[0].length != trackSize.getHeight() ) )
    {
    	for(int x = 0; x < trackSize.getWidth(); x++)
      {
      	for(int y = 0; y < trackSize.getHeight(); y++)
        {
          try
          {
          	field[x][y] = tempArray[x][y];
          }
          catch(ArrayIndexOutOfBoundsException e)
          {
           	field[x][y] = BORDER;
					}
        }
      }
    }
    else
    	field = tempArray;
  }

  public Dimension getTrackSize()
  {
    return trackSize;
  }

  public int getTerrain(int x, int y)
  {
  	return field[x][y];
  }

  public int getGridSize()
  {
  	return gridSize;
  }

  public void setGridSize(int gridSize)
	{
  	this.gridSize = gridSize;
  }
}