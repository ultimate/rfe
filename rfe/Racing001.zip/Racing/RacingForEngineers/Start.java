package RacingForEngineers;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.Cursor;

import RacingForEngineers.*;
import RacingForEngineers.Panels.*;
import RacingForEngineers.ActionListeners.*;

public class Start implements RFEConstants
{
  public static void main(String args[])
  {
    System.out.println("Initializing...");
    //Look-and-Feel setzen
    try
    {
      UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
      System.out.println("Look-And-Feel set to \"Metal\"");
    }
    catch (Exception e)
    {
      System.out.println("Look-And-Feel could not be set! - Using Standard instead!");
    }

    rfegui.setSize(GUISize);
    rfegui.setLocation(100,100);
    rfegui.setVisible(true);

    rfegui.addWindowListener(new RFEGUIListener());
    System.out.println("Hello");

		synchronized(syncobject)
    {
      try
      {
        syncobject.wait();
      }
      catch(Exception e)
      {
      }
    }

    System.out.println("Bye!");
    rfegui.setVisible(false);
		rfegui.dispose();
		System.exit(0);
  }
}