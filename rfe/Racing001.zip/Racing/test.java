import java.awt.image.*;
import javax.swing.*;
import java.awt.*;




public class test
{
  public static void main(String args[])
  {
  	ImageIcon ii = new ImageIcon(args[0]);
    Image i = ii.getImage();
    PixelGrabber pg = new PixelGrabber(i,0,0,i.getWidth(null),i.getHeight(null),true);

    try
    {
    	//pg.startGrabbing();
      pg.grabPixels();
    }
    catch(Exception e)
    {}

    int[] pixel = (int[])pg.getPixels();

    System.out.println(ii + " " + i + " " + pg + " "); //+ pixel.length);

    for(int h = 0; h < pixel.length; h++)
    {
    	System.out.print("" + pixel[h] + "      \t");
      String s = Integer.toBinaryString(pixel[h]);
      System.out.println( Integer.parseInt(s.substring(0,8),2) + ","
      									+ Integer.parseInt(s.substring(8,16),2) + ","
                        + Integer.parseInt(s.substring(16,24),2) + ","
                        + Integer.parseInt(s.substring(24,32),2) );
      System.out.println(s);
      System.out.println(Integer.toHexString(pixel[h]).toUpperCase());
    }
  }
}